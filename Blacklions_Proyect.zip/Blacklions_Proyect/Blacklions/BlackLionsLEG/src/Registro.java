import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class Registro extends javax.swing.JFrame {
    
    public static Connection con;
    public static final String driver = "com.mysql.jdbc.Driver";
    public static final String user = "root";
    public static final String pass = "";
    public static final String url = "jdbc:mysql://localhost:3306/BlackLionsBD";
    PreparedStatement ps;
    ResultSet rs;
    
    public void Conexion() {
        con = null;
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url, user, pass);
            if (con != null) {
            }
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error de conexion" + e);
        }

    }

    public Registro() {
        initComponents();
        this.setResizable(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        TxtUser = new javax.swing.JTextField();
        Password = new javax.swing.JPasswordField();
        TipoUsuario = new javax.swing.JComboBox<>();
        BtnSalir = new javax.swing.JButton();
        BtnRegistar = new javax.swing.JButton();
        jLabel0 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Lucida Sans", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("REGISTRO DE USUARIOS");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 690, 50);

        jLabel2.setFont(new java.awt.Font("Lucida Sans", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("CONSTRASEÑA");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 180, 150, 30);

        jLabel3.setFont(new java.awt.Font("Lucida Sans", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("USUARIO");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(20, 130, 150, 30);
        getContentPane().add(TxtUser);
        TxtUser.setBounds(180, 130, 220, 30);
        getContentPane().add(Password);
        Password.setBounds(180, 180, 220, 30);

        TipoUsuario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "Empleado", "Administrador" }));
        TipoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoUsuarioActionPerformed(evt);
            }
        });
        getContentPane().add(TipoUsuario);
        TipoUsuario.setBounds(440, 130, 140, 30);

        BtnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cerrar_64.png"))); // NOI18N
        BtnSalir.setContentAreaFilled(false);
        BtnSalir.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cerrar_48.png"))); // NOI18N
        BtnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnSalirMouseClicked(evt);
            }
        });
        BtnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(BtnSalir);
        BtnSalir.setBounds(620, 0, 50, 50);

        BtnRegistar.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnRegistar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/gardar_64.png"))); // NOI18N
        BtnRegistar.setText("REGISTAR");
        BtnRegistar.setContentAreaFilled(false);
        BtnRegistar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnRegistar.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/guardar_48.png"))); // NOI18N
        BtnRegistar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnRegistar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRegistarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnRegistar);
        BtnRegistar.setBounds(260, 260, 110, 100);

        jLabel0.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Fondo_Menus.jpg"))); // NOI18N
        getContentPane().add(jLabel0);
        jLabel0.setBounds(0, 0, 710, 470);

        setSize(new java.awt.Dimension(691, 445));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BtnSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnSalirMouseClicked
        /*
        *METODO DEL BOTÓN DE SALIR PARA DIRIGIRSE A KA VENTANA DE LA NOMINA
        */
        new MenuPrincipal().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BtnSalirMouseClicked

    private void BtnRegistarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRegistarActionPerformed
        /*
        *BOTON DE REGISTAR EN EL SISTEMA LOS USUARIOS PARA QUE TENGAN UN ACCESO
        */
        Conexion();
        try {
            ps = con.prepareStatement("INSERT INTO Registros(User,Password,TipoUsuario) VALUES(?,?,?)");
            ps.setString(1,TxtUser.getText());
            ps.setString(2,Password.getText());
            ps.setString(3 , (String) TipoUsuario.getSelectedItem());
            int result = ps.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(null, "REGISTRO GUARDADO");
            } else {
                JOptionPane.showMessageDialog(null, "ERROR AL REGISTRAR");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_BtnRegistarActionPerformed

    private void TipoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoUsuarioActionPerformed

    private void BtnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnSalirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnSalirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnRegistar;
    private javax.swing.JButton BtnSalir;
    private javax.swing.JPasswordField Password;
    private javax.swing.JComboBox<String> TipoUsuario;
    private javax.swing.JTextField TxtUser;
    private javax.swing.JLabel jLabel0;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
