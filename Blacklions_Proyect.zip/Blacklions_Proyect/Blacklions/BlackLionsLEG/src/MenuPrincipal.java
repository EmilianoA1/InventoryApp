
import javax.swing.JOptionPane;

public class MenuPrincipal extends javax.swing.JFrame {

    public MenuPrincipal() {
        initComponents();
        this.setResizable(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BtnRegistros = new javax.swing.JButton();
        BtnInventario = new javax.swing.JButton();
        BtnEmpleados = new javax.swing.JButton();
        BtnNomina = new javax.swing.JButton();
        BtnSalir = new javax.swing.JButton();
        BtnInfo = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        BtnRegistros.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnRegistros.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Registar_64.png"))); // NOI18N
        BtnRegistros.setText("REGISTAR");
        BtnRegistros.setContentAreaFilled(false);
        BtnRegistros.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnRegistros.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Registrar_72.png"))); // NOI18N
        BtnRegistros.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnRegistros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRegistrosActionPerformed(evt);
            }
        });
        getContentPane().add(BtnRegistros);
        BtnRegistros.setBounds(0, 290, 110, 110);

        BtnInventario.setFont(new java.awt.Font("Lucida Sans", 1, 14)); // NOI18N
        BtnInventario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/1486504352-checklist-clipboard-inventory-list-report-tasks-todo_81326.png"))); // NOI18N
        BtnInventario.setText("INVENTARIO");
        BtnInventario.setToolTipText("Inventario");
        BtnInventario.setContentAreaFilled(false);
        BtnInventario.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnInventario.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/inventario_64.png"))); // NOI18N
        BtnInventario.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnInventario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnInventarioActionPerformed(evt);
            }
        });
        getContentPane().add(BtnInventario);
        BtnInventario.setBounds(0, 130, 160, 130);

        BtnEmpleados.setFont(new java.awt.Font("Lucida Sans", 1, 14)); // NOI18N
        BtnEmpleados.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/effective_employees_users_team_group_icon_152042.png"))); // NOI18N
        BtnEmpleados.setText("EMPLEADOS");
        BtnEmpleados.setToolTipText("Empleados");
        BtnEmpleados.setContentAreaFilled(false);
        BtnEmpleados.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnEmpleados.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/empleados_64.png"))); // NOI18N
        BtnEmpleados.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnEmpleados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnEmpleadosMouseClicked(evt);
            }
        });
        getContentPane().add(BtnEmpleados);
        BtnEmpleados.setBounds(320, 130, 160, 130);

        BtnNomina.setFont(new java.awt.Font("Lucida Sans", 1, 14)); // NOI18N
        BtnNomina.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/artboard_123062.png"))); // NOI18N
        BtnNomina.setText("NOMINA");
        BtnNomina.setToolTipText("Nomina");
        BtnNomina.setContentAreaFilled(false);
        BtnNomina.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnNomina.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/nomins_64.png"))); // NOI18N
        BtnNomina.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnNomina.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnNominaMouseClicked(evt);
            }
        });
        BtnNomina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnNominaActionPerformed(evt);
            }
        });
        getContentPane().add(BtnNomina);
        BtnNomina.setBounds(160, 130, 160, 130);

        BtnSalir.setFont(new java.awt.Font("Lucida Sans", 1, 14)); // NOI18N
        BtnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/4115235-exit-logout-sign-out_114030 (1).png"))); // NOI18N
        BtnSalir.setText("SALIR");
        BtnSalir.setToolTipText("Salir");
        BtnSalir.setContentAreaFilled(false);
        BtnSalir.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnSalir.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Salir_64 (2).png"))); // NOI18N
        BtnSalir.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnSalirMouseClicked(evt);
            }
        });
        BtnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(BtnSalir);
        BtnSalir.setBounds(480, 130, 150, 130);

        BtnInfo.setFont(new java.awt.Font("Lucida Sans", 1, 10)); // NOI18N
        BtnInfo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Info_48.png"))); // NOI18N
        BtnInfo.setText("INFORMACIÓN");
        BtnInfo.setToolTipText("Información");
        BtnInfo.setContentAreaFilled(false);
        BtnInfo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnInfo.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Info_32.png"))); // NOI18N
        BtnInfo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnInfo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnInfoMouseClicked(evt);
            }
        });
        BtnInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnInfoActionPerformed(evt);
            }
        });
        getContentPane().add(BtnInfo);
        BtnInfo.setBounds(500, 300, 120, 100);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Lucida Sans", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("BLACKLIONS");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 620, 50);

        jLabel2.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/fondo_menu.jpg"))); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 710, 480);

        setSize(new java.awt.Dimension(623, 449));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BtnInventarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnInventarioActionPerformed
        //METEDO PARA PODER INGRESAR AL MENU DE INVENTARIO
        new Inventario().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BtnInventarioActionPerformed

    private void BtnSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnSalirMouseClicked
        //METODO PARA CERRAR EL PROGRAMA
        System.exit(0);
    }//GEN-LAST:event_BtnSalirMouseClicked

    private void BtnNominaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnNominaMouseClicked
        //METEDO PARA PODER INGRESAR AL MENU DE NOMINA
        new Nomina().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BtnNominaMouseClicked

    private void BtnEmpleadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnEmpleadosMouseClicked
        //METEDO PARA PODER INGRESAR AL MENU DE EMPLEADOS
        new Empleados().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BtnEmpleadosMouseClicked

    private void BtnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnSalirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnSalirActionPerformed

    private void BtnNominaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnNominaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnNominaActionPerformed

    private void BtnInfoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnInfoMouseClicked
        //METEDO PARA PODER INGRESAR A LA VENTANA DE MENU
        new Creditos().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BtnInfoMouseClicked

    private void BtnInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnInfoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnInfoActionPerformed

    private void BtnRegistrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRegistrosActionPerformed
        // TODO add your handling code here:
        new Registro().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BtnRegistrosActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnEmpleados;
    private javax.swing.JButton BtnInfo;
    private javax.swing.JButton BtnInventario;
    private javax.swing.JButton BtnNomina;
    private javax.swing.JButton BtnRegistros;
    private javax.swing.JButton BtnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
