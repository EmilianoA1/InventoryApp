import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import javax.swing.JOptionPane;


public class Imprimir extends javax.swing.JFrame implements Printable {

    public Imprimir() {
        initComponents();
        this.setResizable(false);
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        NominaImp = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        TxtDescSalarioI = new javax.swing.JTextField();
        TxtNombreI = new javax.swing.JTextField();
        TxtSalarioI = new javax.swing.JTextField();
        TxtFaltasI = new javax.swing.JTextField();
        TxtPuestoI = new javax.swing.JTextField();
        TxtNumEmpI = new javax.swing.JTextField();
        TxtNSSI = new javax.swing.JTextField();
        TxtRFCI = new javax.swing.JTextField();
        DateEnding = new javax.swing.JTextField();
        DateInitial = new javax.swing.JTextField();
        BtnImprimir = new javax.swing.JButton();
        BtnCancelar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        NominaImp.setBackground(new java.awt.Color(255, 255, 255));
        NominaImp.setLayout(null);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Logo_BL.jpeg"))); // NOI18N
        NominaImp.add(jLabel1);
        jLabel1.setBounds(-30, 0, 170, 138);

        jLabel2.setFont(new java.awt.Font("Lucida Sans", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("BLACKLIONS-LEG");
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        NominaImp.add(jLabel2);
        jLabel2.setBounds(141, 0, 420, 50);

        jLabel3.setText("DESCT SALARIO");
        NominaImp.add(jLabel3);
        jLabel3.setBounds(10, 220, 110, 30);

        jLabel4.setText("NOMBRE");
        NominaImp.add(jLabel4);
        jLabel4.setBounds(160, 50, 80, 30);

        jLabel5.setText("NSS");
        NominaImp.add(jLabel5);
        jLabel5.setBounds(10, 410, 80, 30);

        jLabel6.setText("FIN DE PERIODO");
        NominaImp.add(jLabel6);
        jLabel6.setBounds(10, 310, 130, 30);

        jLabel7.setText("SALARIO");
        NominaImp.add(jLabel7);
        jLabel7.setBounds(10, 180, 80, 30);

        jLabel8.setText("INICIO DE PERIODO");
        NominaImp.add(jLabel8);
        jLabel8.setBounds(10, 270, 130, 30);

        jLabel9.setText("FALTAS");
        NominaImp.add(jLabel9);
        jLabel9.setBounds(330, 270, 70, 30);

        jLabel10.setText("PUESTO");
        NominaImp.add(jLabel10);
        jLabel10.setBounds(160, 90, 80, 30);

        jLabel11.setText("NUM. EMP");
        NominaImp.add(jLabel11);
        jLabel11.setBounds(160, 130, 80, 30);

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jLabel12.setText("FIRMA :");
        NominaImp.add(jLabel12);
        jLabel12.setBounds(310, 450, 50, 40);

        jLabel13.setText("________________________");
        NominaImp.add(jLabel13);
        jLabel13.setBounds(370, 450, 180, 40);

        jLabel14.setText("RFC");
        NominaImp.add(jLabel14);
        jLabel14.setBounds(10, 370, 80, 30);

        TxtDescSalarioI.setEditable(false);
        NominaImp.add(TxtDescSalarioI);
        TxtDescSalarioI.setBounds(120, 220, 260, 30);

        TxtNombreI.setEditable(false);
        NominaImp.add(TxtNombreI);
        TxtNombreI.setBounds(240, 50, 260, 30);

        TxtSalarioI.setEditable(false);
        NominaImp.add(TxtSalarioI);
        TxtSalarioI.setBounds(120, 180, 260, 30);

        TxtFaltasI.setEditable(false);
        NominaImp.add(TxtFaltasI);
        TxtFaltasI.setBounds(400, 270, 130, 30);

        TxtPuestoI.setEditable(false);
        NominaImp.add(TxtPuestoI);
        TxtPuestoI.setBounds(240, 90, 260, 30);

        TxtNumEmpI.setEditable(false);
        NominaImp.add(TxtNumEmpI);
        TxtNumEmpI.setBounds(240, 130, 260, 30);

        TxtNSSI.setEditable(false);
        NominaImp.add(TxtNSSI);
        TxtNSSI.setBounds(90, 410, 260, 30);

        TxtRFCI.setEditable(false);
        NominaImp.add(TxtRFCI);
        TxtRFCI.setBounds(90, 370, 260, 30);

        DateEnding.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DateEndingActionPerformed(evt);
            }
        });
        NominaImp.add(DateEnding);
        DateEnding.setBounds(130, 310, 180, 30);

        DateInitial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DateInitialActionPerformed(evt);
            }
        });
        NominaImp.add(DateInitial);
        DateInitial.setBounds(130, 270, 180, 30);

        getContentPane().add(NominaImp);
        NominaImp.setBounds(0, 0, 650, 490);

        BtnImprimir.setText("IMPRIMIR");
        BtnImprimir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnImprimirMouseClicked(evt);
            }
        });
        getContentPane().add(BtnImprimir);
        BtnImprimir.setBounds(450, 500, 100, 40);

        BtnCancelar.setText("CANCELAR");
        BtnCancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnCancelarMouseClicked(evt);
            }
        });
        getContentPane().add(BtnCancelar);
        BtnCancelar.setBounds(10, 500, 100, 40);

        setSize(new java.awt.Dimension(573, 596));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BtnImprimirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnImprimirMouseClicked
        /*
        *METODO DEL BOTON IMPRIMIR
        */
        try{
            PrinterJob gap = PrinterJob.getPrinterJob();
            gap.setPrintable(this);
            boolean top = gap.printDialog();
            if(top){
                gap.print();
            }
        }catch(PrinterException pex){
            JOptionPane.showMessageDialog(null, "ERROR DE PROGRAMA","Error\n"+pex,JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_BtnImprimirMouseClicked

    private void BtnCancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnCancelarMouseClicked
        this.setVisible(false);
    }//GEN-LAST:event_BtnCancelarMouseClicked

    
    //ESTOS CAMPOS DEBEN SER REMPLAZADOS POR CAMPOS DE FECHA DE LA LIBRERIA DE JCALENDAR.
    private void DateEndingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DateEndingActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DateEndingActionPerformed

    private void DateInitialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DateInitialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DateInitialActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Imprimir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Imprimir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Imprimir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Imprimir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Imprimir().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnCancelar;
    private javax.swing.JButton BtnImprimir;
    private javax.swing.JTextField DateEnding;
    private javax.swing.JTextField DateInitial;
    private javax.swing.JPanel NominaImp;
    public static javax.swing.JTextField TxtDescSalarioI;
    public static javax.swing.JTextField TxtFaltasI;
    public static javax.swing.JTextField TxtNSSI;
    public static javax.swing.JTextField TxtNombreI;
    public static javax.swing.JTextField TxtNumEmpI;
    public static javax.swing.JTextField TxtPuestoI;
    public static javax.swing.JTextField TxtRFCI;
    public static javax.swing.JTextField TxtSalarioI;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    // End of variables declaration//GEN-END:variables

    @Override
    public int print(Graphics graf, PageFormat pagfor, int index) throws PrinterException {
        /*
        *METODO ABSTRACTO PARA REALIZAR LA COMPARACIÓN DE SI LA HOJA TIENE ALGO O NO PARA IMPRIMIR
        */
        
        if(index>0){
            return NO_SUCH_PAGE; 
        }
        
        Graphics2D hub = (Graphics2D) graf;
        hub.translate(pagfor.getImageableX()+30, pagfor.getImageableY()+30);
        
        NominaImp.paintAll(graf);
        return PAGE_EXISTS;
    }
}
