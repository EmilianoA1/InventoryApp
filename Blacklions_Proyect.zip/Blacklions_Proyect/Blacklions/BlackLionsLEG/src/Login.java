import java.sql.*;
import javax.swing.JOptionPane;

public class Login extends javax.swing.JFrame {

    public static Connection con;
    public static final String driver = "com.mysql.jdbc.Driver";
    public static final String user = "root";
    public static final String pass = "root";
    public static final String url = "jdbc:mysql://localhost:3306/BlackLionsBD";

    public void Conexion() {
        /*
        *METODO PARA LA CONEXION A LA BD 
        */
        con = null;
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url, user, pass);
            if (con != null) {
                LblEstado.setText("CONECTADO");
            }
        } catch (ClassNotFoundException | SQLException e) {
            LblEstado.setText("Error de conexion" + e);
        }

    }

    public Login() {
        initComponents();
        this.setResizable(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        Password = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        TxtUser = new javax.swing.JTextField();
        btnIngreso = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        LblEstado = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(null);

        jLabel3.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("CONTRASEÑA");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 110, 110, 30);
        jPanel1.add(Password);
        Password.setBounds(130, 110, 210, 30);

        jLabel1.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("USUARIO");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(20, 60, 110, 30);
        jPanel1.add(TxtUser);
        TxtUser.setBounds(130, 60, 210, 30);

        btnIngreso.setBackground(new java.awt.Color(0, 0, 0));
        btnIngreso.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        btnIngreso.setForeground(new java.awt.Color(255, 255, 255));
        btnIngreso.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Login_64.png"))); // NOI18N
        btnIngreso.setText("INGRESAR");
        btnIngreso.setToolTipText("Ingresar");
        btnIngreso.setContentAreaFilled(false);
        btnIngreso.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnIngreso.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnIngreso.setName(""); // NOI18N
        btnIngreso.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Login_48.png"))); // NOI18N
        btnIngreso.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnIngreso.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnIngresoMouseClicked(evt);
            }
        });
        btnIngreso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresoActionPerformed(evt);
            }
        });
        jPanel1.add(btnIngreso);
        btnIngreso.setBounds(300, 200, 100, 110);
        btnIngreso.getAccessibleContext().setAccessibleDescription("");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Logo_BL.jpeg"))); // NOI18N
        jPanel1.add(jLabel2);
        jLabel2.setBounds(-20, 160, 170, 140);

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Lucida Sans", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("BLACKLIONS");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(0, 0, 230, 50);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 450, 350);

        LblEstado.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        LblEstado.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        LblEstado.setText("ESTADO");
        LblEstado.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(LblEstado);
        LblEstado.setBounds(150, 240, 50, 60);

        setSize(new java.awt.Dimension(417, 351));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnIngresoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnIngresoMouseClicked
        // TODO add your handling code here:
        /*
        *METODO PARA EL INGRESO AL SISTEMA VALIDANDO SI EL USUARIO Y CONTRASEÑA SON CORRECTOS
        */
        Conexion();
        String Usuario = new String(TxtUser.getText());
        String Contraseña = new String(Password.getText());
        String DateAcces = "";
        String sql = "SELECT * FROM Registros WHERE User='" + Usuario +"' && Password='"+ Contraseña +"'";
        try{
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                DateAcces = rs.getString("TipoUsuario");
            }
            if(DateAcces.equals("Administrador")){
                new MenuPrincipal().setVisible(true);
                this.setVisible(false);
            }else{
                if(DateAcces.equals("Empleado")){
                    new MenuEmpleados().setVisible(true);
                    this.setVisible(false);
                }else{
                    JOptionPane.showMessageDialog(null,"USUARIO Y/O CONTRASEÑA INCORRECTOS");
                }
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_btnIngresoMouseClicked

    private void btnIngresoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnIngresoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LblEstado;
    private javax.swing.JPasswordField Password;
    private javax.swing.JTextField TxtUser;
    private javax.swing.JButton btnIngreso;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
