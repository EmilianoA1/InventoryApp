
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Nomina extends javax.swing.JFrame {

    public static Connection con;
    public static final String driver = "com.mysql.jdbc.Driver";
    public static final String user = "root";
    public static final String pass = "root";
    public static final String url = "jdbc:mysql://localhost:3306/BlackLionsBD";
    PreparedStatement ps;
    ResultSet rs;

    public void Conexion() {
        con = null;
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url, user, pass);
            if (con != null) {
            }
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error de conexion" + e);
        }

    }

    private void CleanTexts() {
        TxtNumEmp.setText(null);
        TxtNombre.setText(null);
        TxtPuesto.setText(null);
        TxtDesc.setText(null);
        TxtSueldo.setText(null);
        TxtRFC.setText(null);
        TxtNSS.setText(null);
        //DateInicio.setDate(null);
        //DateFin.setDate(null);
        TxtFaltas.setText(null);
    }

    public Nomina() {
        initComponents();
        this.setResizable(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TxtAux = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        TxtNumEmp = new javax.swing.JTextField();
        TxtNombre = new javax.swing.JTextField();
        TxtPuesto = new javax.swing.JTextField();
        TxtSueldo = new javax.swing.JTextField();
        TxtDesc = new javax.swing.JTextField();
        TxtRFC = new javax.swing.JTextField();
        TxtNSS = new javax.swing.JTextField();
        TxtFaltas = new javax.swing.JTextField();
        BtnSalir = new javax.swing.JButton();
        BtnCalcularSueldo = new javax.swing.JButton();
        BtnImprimir = new javax.swing.JButton();
        BtnNuevo = new javax.swing.JButton();
        BtnBuscar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        TxtAux.setFont(new java.awt.Font("Lucida Sans", 1, 24)); // NOI18N
        TxtAux.setForeground(new java.awt.Color(255, 255, 255));
        TxtAux.setText("NOMINA");
        getContentPane().add(TxtAux);
        TxtAux.setBounds(0, 0, 412, 54);

        jLabel2.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("NUM. EMPLEADO");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(40, 80, 150, 30);

        jLabel3.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("NOMBRE");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(40, 130, 150, 30);

        jLabel5.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("PUESTO");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(40, 180, 150, 30);

        jLabel6.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("SALARIO");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(40, 280, 150, 30);

        jLabel7.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("DESCT DE SALARIO");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(40, 230, 150, 30);

        jLabel8.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("RFC");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(410, 80, 150, 30);

        jLabel9.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("PERIODO DE INICIO");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(410, 180, 150, 30);

        jLabel10.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("CIERRE DE PERIODO");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(410, 230, 150, 30);

        jLabel11.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("FALTAS");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(410, 280, 150, 30);

        jLabel12.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("NSS");
        getContentPane().add(jLabel12);
        jLabel12.setBounds(410, 130, 150, 30);

        TxtNumEmp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtNumEmpKeyTyped(evt);
            }
        });
        getContentPane().add(TxtNumEmp);
        TxtNumEmp.setBounds(190, 80, 170, 30);

        TxtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtNombreKeyTyped(evt);
            }
        });
        getContentPane().add(TxtNombre);
        TxtNombre.setBounds(190, 130, 170, 30);

        TxtPuesto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtPuestoKeyTyped(evt);
            }
        });
        getContentPane().add(TxtPuesto);
        TxtPuesto.setBounds(190, 180, 170, 30);

        TxtSueldo.setEditable(false);
        getContentPane().add(TxtSueldo);
        TxtSueldo.setBounds(190, 280, 170, 30);

        TxtDesc.setEditable(false);
        TxtDesc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtDescKeyTyped(evt);
            }
        });
        getContentPane().add(TxtDesc);
        TxtDesc.setBounds(190, 230, 170, 30);

        TxtRFC.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtRFCKeyTyped(evt);
            }
        });
        getContentPane().add(TxtRFC);
        TxtRFC.setBounds(560, 80, 170, 30);

        TxtNSS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtNSSKeyTyped(evt);
            }
        });
        getContentPane().add(TxtNSS);
        TxtNSS.setBounds(560, 130, 170, 30);

        TxtFaltas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtFaltasKeyTyped(evt);
            }
        });
        getContentPane().add(TxtFaltas);
        TxtFaltas.setBounds(560, 280, 170, 30);

        BtnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cerrar_64.png"))); // NOI18N
        BtnSalir.setContentAreaFilled(false);
        BtnSalir.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cerrar_48.png"))); // NOI18N
        BtnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnSalirMouseClicked(evt);
            }
        });
        BtnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(BtnSalir);
        BtnSalir.setBounds(730, 0, 70, 60);

        BtnCalcularSueldo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Calcular_72.png"))); // NOI18N
        BtnCalcularSueldo.setText("CALCULAR SUELDO");
        BtnCalcularSueldo.setContentAreaFilled(false);
        BtnCalcularSueldo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnCalcularSueldo.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Calcular_64.png"))); // NOI18N
        BtnCalcularSueldo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnCalcularSueldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCalcularSueldoActionPerformed(evt);
            }
        });
        getContentPane().add(BtnCalcularSueldo);
        BtnCalcularSueldo.setBounds(410, 350, 170, 100);

        BtnImprimir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Imprimir_72.png"))); // NOI18N
        BtnImprimir.setText("IMPRIMIR");
        BtnImprimir.setContentAreaFilled(false);
        BtnImprimir.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnImprimir.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Imprimir_64.png"))); // NOI18N
        BtnImprimir.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnImprimir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnImprimirMouseClicked(evt);
            }
        });
        getContentPane().add(BtnImprimir);
        BtnImprimir.setBounds(600, 350, 170, 100);

        BtnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Nuevo_72.png"))); // NOI18N
        BtnNuevo.setText("NUEVO");
        BtnNuevo.setContentAreaFilled(false);
        BtnNuevo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnNuevo.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Nuevo_64.png"))); // NOI18N
        BtnNuevo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnNuevo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnNuevoMouseClicked(evt);
            }
        });
        getContentPane().add(BtnNuevo);
        BtnNuevo.setBounds(220, 350, 170, 100);

        BtnBuscar.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Buscar_72.png"))); // NOI18N
        BtnBuscar.setText("BUSCAR");
        BtnBuscar.setContentAreaFilled(false);
        BtnBuscar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnBuscar.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Buscar_64.png"))); // NOI18N
        BtnBuscar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnBuscar);
        BtnBuscar.setBounds(30, 350, 170, 100);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Fondo_Menus.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 860, 580);

        setSize(new java.awt.Dimension(815, 530));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BtnCalcularSueldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCalcularSueldoActionPerformed
        // TODO add your handling code here:
        new CalcularS().setVisible(true);
    }//GEN-LAST:event_BtnCalcularSueldoActionPerformed

    private void BtnSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnSalirMouseClicked
        new MenuPrincipal().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BtnSalirMouseClicked

    private void BtnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnSalirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnSalirActionPerformed

    private void BtnImprimirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnImprimirMouseClicked
        new Imprimir().setVisible(true);
        Imprimir.TxtNombreI.setText(TxtNombre.getText());
        Imprimir.TxtPuestoI.setText(TxtPuesto.getText());
        Imprimir.TxtNumEmpI.setText(TxtNumEmp.getText());
        Imprimir.TxtSalarioI.setText(TxtSueldo.getText());
        Imprimir.TxtDescSalarioI.setText(TxtDesc.getText());
        //Imprimir.DateInicioI.setDate(DateInicio.getDate());
        //Imprimir.DateFinI.setDate(DateFin.getDate());
        Imprimir.TxtFaltasI.setText(TxtFaltas.getText());
        Imprimir.TxtRFCI.setText(TxtRFC.getText());
        Imprimir.TxtNSSI.setText(TxtNSS.getText());
        
        
    }//GEN-LAST:event_BtnImprimirMouseClicked

    private void BtnNuevoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnNuevoMouseClicked
        CleanTexts();
    }//GEN-LAST:event_BtnNuevoMouseClicked

    private void BtnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBuscarActionPerformed
        Conexion();
        try {
            ps = con.prepareStatement("SELECT NumEmp,NombreEmp,PuestoEmp,RFC,NSS FROM Empleados WHERE NumEmp=?");
            ps.setInt(1, Integer.parseInt(TxtNumEmp.getText()));
            rs = ps.executeQuery();
            if (rs.next()) {
                TxtNombre.setText(rs.getString("NombreEmp"));
                TxtPuesto.setText(rs.getString("PuestoEmp"));
                TxtRFC.setText(rs.getString("RFC"));
                TxtNSS.setText(rs.getString("NSS"));
            } else {
                JOptionPane.showMessageDialog(null, "EMPLEADO NO ENCONTRADO");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "DEBES INGRESAR EL NUMERO DEL EMPLEADO");
        }
    }//GEN-LAST:event_BtnBuscarActionPerformed

    private void TxtNumEmpKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtNumEmpKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 47 || evt.getKeyChar() >= 58 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtNumEmpKeyTyped

    private void TxtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtNombreKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 64 || evt.getKeyChar() >= 91 && evt.getKeyChar() <= 96 || evt.getKeyChar() >= 123 && evt.getKeyChar() <= 163 || evt.getKeyChar() >= 166 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtNombreKeyTyped

    private void TxtPuestoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtPuestoKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 64 || evt.getKeyChar() >= 91 && evt.getKeyChar() <= 96 || evt.getKeyChar() >= 123 && evt.getKeyChar() <= 163 || evt.getKeyChar() >= 166 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtPuestoKeyTyped

    private void TxtRFCKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtRFCKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 47 || evt.getKeyChar() >= 58 && evt.getKeyChar() <= 64 || evt.getKeyChar() >= 91 && evt.getKeyChar() <= 163 || evt.getKeyChar() >= 166 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtRFCKeyTyped

    private void TxtNSSKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtNSSKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 47 || evt.getKeyChar() >= 58 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtNSSKeyTyped

    private void TxtFaltasKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtFaltasKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 47 || evt.getKeyChar() >= 58 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtFaltasKeyTyped


    private void TxtDescKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtDescKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtDescKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Nomina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Nomina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Nomina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Nomina.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Nomina().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnBuscar;
    private javax.swing.JButton BtnCalcularSueldo;
    private javax.swing.JButton BtnImprimir;
    private javax.swing.JButton BtnNuevo;
    private javax.swing.JButton BtnSalir;
    private javax.swing.JLabel TxtAux;
    public static javax.swing.JTextField TxtDesc;
    public static javax.swing.JTextField TxtFaltas;
    public static javax.swing.JTextField TxtNSS;
    public static javax.swing.JTextField TxtNombre;
    public static javax.swing.JTextField TxtNumEmp;
    public static javax.swing.JTextField TxtPuesto;
    public static javax.swing.JTextField TxtRFC;
    public static javax.swing.JTextField TxtSueldo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    // End of variables declaration//GEN-END:variables

}
