
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Empleados extends javax.swing.JFrame {

    public static Connection con;
    public static final String driver = "com.mysql.jdbc.Driver";
    public static final String user = "root";
    public static final String pass = "root";
    public static final String url = "jdbc:mysql://localhost:3306/BlackLionsBD";
    PreparedStatement ps;
    ResultSet rs;
    DefaultTableModel Tabla;

    public void Conexion() {
        /*
        *METODO PARA REALIZAR LA CONCEXION A LA BD
         */
        con = null;
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url, user, pass);
            if (con != null) {
            }
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error de conexion" + e);
        }

    }

    public void CleanTexts() {
        /*
        *METODO PARA LIMPIAR LOS CAMPOS DE TEXTO
         */
        TxtNombreEmp.setText(null);
        TxtNumEmp.setText(null);
        TxtPuesto.setText(null);
        TxtNSS.setText(null);
        TxtNumTel.setText(null);
        TxtSangre.setText(null);
        TxtRFCEmp.setText(null);
        TxtCURP.setText(null);
    }

    public Empleados() {
        initComponents();
        this.setResizable(false);
        Tabla = new DefaultTableModel();
        TablaEmp.setModel(Tabla);
        Tabla.addColumn("NumEmp");
        Tabla.addColumn("NombreEmp");
        Tabla.addColumn("PuestoEmp");
        Tabla.addColumn("NSS");
        Tabla.addColumn("NumTel");
        Tabla.addColumn("TipoSangre");
        Tabla.addColumn("RFC");
        Tabla.addColumn("CURP");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TablaEmp = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        TxtNumEmp = new javax.swing.JTextField();
        TxtNombreEmp = new javax.swing.JTextField();
        TxtPuesto = new javax.swing.JTextField();
        TxtNSS = new javax.swing.JTextField();
        TxtNumTel = new javax.swing.JTextField();
        TxtSangre = new javax.swing.JTextField();
        TxtRFCEmp = new javax.swing.JTextField();
        TxtCURP = new javax.swing.JTextField();
        BtnBuscar = new javax.swing.JButton();
        BtnRegistar = new javax.swing.JButton();
        BtnEliminar = new javax.swing.JButton();
        BtnModificar = new javax.swing.JButton();
        BtnSalir = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        TablaEmp.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "NUMERO EMPLEADO", "NOMBRE", "PUESTO", "NSS", "NUM. TEL", "TIPO SANGRE", "RFC", "CURP"
            }
        ));
        jScrollPane1.setViewportView(TablaEmp);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(0, 470, 750, 120);

        jLabel1.setFont(new java.awt.Font("Lucida Sans", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("EMPLEADOS");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 393, 65);

        jLabel2.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("NUM. EMPLEADO");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(40, 260, 130, 30);

        jLabel3.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("NOM. COMPLETO");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(40, 310, 130, 30);

        jLabel4.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("NSS");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(40, 410, 130, 30);

        jLabel5.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("PUESTO");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(40, 360, 130, 30);

        jLabel6.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("NUM. TELEFONO");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(390, 260, 130, 30);

        jLabel7.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("TIPO SANGRE");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(390, 310, 130, 30);

        jLabel8.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("RFC");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(390, 360, 130, 30);

        jLabel9.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("CURP");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(390, 410, 130, 30);

        TxtNumEmp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtNumEmpKeyTyped(evt);
            }
        });
        getContentPane().add(TxtNumEmp);
        TxtNumEmp.setBounds(170, 260, 170, 30);

        TxtNombreEmp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtNombreEmpKeyTyped(evt);
            }
        });
        getContentPane().add(TxtNombreEmp);
        TxtNombreEmp.setBounds(170, 310, 170, 30);

        TxtPuesto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtPuestoKeyTyped(evt);
            }
        });
        getContentPane().add(TxtPuesto);
        TxtPuesto.setBounds(170, 360, 170, 30);

        TxtNSS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtNSSKeyTyped(evt);
            }
        });
        getContentPane().add(TxtNSS);
        TxtNSS.setBounds(170, 410, 170, 30);

        TxtNumTel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtNumTelKeyTyped(evt);
            }
        });
        getContentPane().add(TxtNumTel);
        TxtNumTel.setBounds(520, 260, 170, 30);

        TxtSangre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtSangreKeyTyped(evt);
            }
        });
        getContentPane().add(TxtSangre);
        TxtSangre.setBounds(520, 310, 170, 30);

        TxtRFCEmp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtRFCEmpKeyTyped(evt);
            }
        });
        getContentPane().add(TxtRFCEmp);
        TxtRFCEmp.setBounds(520, 360, 170, 30);

        TxtCURP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtCURPKeyTyped(evt);
            }
        });
        getContentPane().add(TxtCURP);
        TxtCURP.setBounds(520, 410, 170, 30);

        BtnBuscar.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Buscar_72.png"))); // NOI18N
        BtnBuscar.setText("BUSCAR");
        BtnBuscar.setContentAreaFilled(false);
        BtnBuscar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnBuscar.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Buscar_64.png"))); // NOI18N
        BtnBuscar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnBuscar);
        BtnBuscar.setBounds(140, 80, 110, 100);

        BtnRegistar.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnRegistar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/gardar_64.png"))); // NOI18N
        BtnRegistar.setText("REGISTAR");
        BtnRegistar.setContentAreaFilled(false);
        BtnRegistar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnRegistar.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/guardar_48.png"))); // NOI18N
        BtnRegistar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnRegistar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRegistarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnRegistar);
        BtnRegistar.setBounds(260, 80, 110, 100);

        BtnEliminar.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Eliminar_64.png"))); // NOI18N
        BtnEliminar.setText("ELIMINAR");
        BtnEliminar.setContentAreaFilled(false);
        BtnEliminar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnEliminar.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Eliminar_48.png"))); // NOI18N
        BtnEliminar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEliminarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnEliminar);
        BtnEliminar.setBounds(400, 80, 110, 100);

        BtnModificar.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Editar_64.png"))); // NOI18N
        BtnModificar.setText("MODIFICAR");
        BtnModificar.setContentAreaFilled(false);
        BtnModificar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnModificar.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Editar_48.png"))); // NOI18N
        BtnModificar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnModificarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnModificar);
        BtnModificar.setBounds(520, 80, 109, 100);

        BtnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cerrar_64.png"))); // NOI18N
        BtnSalir.setContentAreaFilled(false);
        BtnSalir.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cerrar_48.png"))); // NOI18N
        BtnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnSalirMouseClicked(evt);
            }
        });
        getContentPane().add(BtnSalir);
        BtnSalir.setBounds(680, 0, 70, 60);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Fondo_Menus.jpg"))); // NOI18N
        getContentPane().add(jLabel10);
        jLabel10.setBounds(0, 0, 870, 710);

        setSize(new java.awt.Dimension(768, 629));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BtnRegistarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRegistarActionPerformed
        /*
        *METODO DEL BOTON REGISTAR PARA REGISTAR A LOS EMPLEADOS NUEVOS
         */
        Conexion();
        try {
            ps = con.prepareStatement("INSERT INTO Empleados (NumEmp,NombreEmp,PuestoEmp,NSS,NumTel,TipoSangre,RFC,CURP) VALUES(?,?,?,?,?,?,?,?)");
            //SENTECIA DE SQL PARA REALIZAR EL REGISTRO DE DATOS EN LA BD
            ps.setInt(1, Integer.parseInt(TxtNumEmp.getText()));
            ps.setString(2, TxtNombreEmp.getText());
            ps.setString(3, TxtPuesto.getText());
            ps.setInt(4, Integer.parseInt(TxtNSS.getText()));
            ps.setInt(5, Integer.parseInt(TxtNumTel.getText()));
            ps.setString(6, TxtSangre.getText());
            ps.setString(7, TxtRFCEmp.getText());
            ps.setString(8, TxtCURP.getText());
            int result = ps.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(null, "REGISTRO GUARDADO");
                CleanTexts();
            } else {
                JOptionPane.showMessageDialog(null, "ERROR AL REGISTRAR");
            }
            con.close();
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
        }
    }//GEN-LAST:event_BtnRegistarActionPerformed

    private void BtnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEliminarActionPerformed
        /*
        *METODO DEL BOTON DE ELIMIAR, ELIMINA REGISTROS DE LA BD COLOCANDO EL NUMERO DEL EMPLEADO
         */
        Conexion();
        try {
            ps = con.prepareStatement("DELETE FROM Empleados WHERE NumEmp=?");
            //SENTENCIA SQL PARA ELIMINAR LOS DATOS
            ps.setInt(1, Integer.parseInt(TxtNumEmp.getText()));
            int res = ps.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "SE HA ELIMINADO EL REGISTRO EXITOSAMENTE");
                CleanTexts();
            } else {
                JOptionPane.showMessageDialog(null, "NO SE HA PODIDO ELIMINAR EL REGISTRO");
            }
        } catch (Exception e) {
            System.err.print(e);
        }
    }//GEN-LAST:event_BtnEliminarActionPerformed

    private void BtnSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnSalirMouseClicked
        /*
        *METODO DEL BOTON DE SALIR, TE TRASLADA A LA VENTANA DEL MENU PRINCIPAL
         */
        new MenuPrincipal().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BtnSalirMouseClicked

    private void BtnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBuscarActionPerformed
        /*
        *METODO DE BOTON DE BUSCAR, HACE LAS BUSQUEDAS EN LA BD CON EL NUMERO DEL EMPLEADO
         */
        int band = 0;//BANDERA PARA VERIFICAR SI LA TABLA MOSTRO LOS DATOS QUE NECESITABA
        Conexion();
        if (TxtNumEmp.getText().equals("")) {
            try {
                ps = con.prepareStatement("SELECT * FROM Empleados");
                Tabla.setRowCount(0);
                rs = ps.executeQuery();
                while (rs.next()) {
                    band = 1;
                    Tabla.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getInt(5), rs.getString(6), rs.getString(7), rs.getString(8)});
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        } else {
            try {
                ps = con.prepareStatement("SELECT * FROM Empleados WHERE NumEmp=?");
                //SENTECIA DE SQL PARA REALIZAR LA BUSQUEDA
                ps.setInt(1, Integer.parseInt(TxtNumEmp.getText()));
                Tabla.setRowCount(0);
                rs = ps.executeQuery();
                while (rs.next()) {
                    band = 1;
                    Tabla.addRow(new Object[]{rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getInt(5), rs.getString(6), rs.getString(7), rs.getString(8)});
                }
                if (band == 0) {
                    JOptionPane.showMessageDialog(null, "REGISTRO NO ENCONTRADO");
                    CleanTexts();
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }//GEN-LAST:event_BtnBuscarActionPerformed

    private void BtnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnModificarActionPerformed
        /*
        *METODO DEL BOTON DE MODIFICAR, SE MODIFICA AL PONER LOS DATOS QUE SE QUIERAN CAMBIAR EN LOS CAMPOS DE TEXTO, SE BASA EN EL NUMERO DEL EMPLEADO
         */
        Conexion();
        try {
            ps = con.prepareStatement("UPDATE Empleados SET NombreEmp=?,PuestoEmp=?,NSS=?,NumTel=?,TipoSangre=?,RFC=?,CURP=? WHERE NumEmp=?");
            //SENTENCIA DE SQL PARA REALIZAR LA MODIFICACIÓN
            ps.setInt(8, Integer.parseInt(TxtNumEmp.getText()));
            ps.setString(1, TxtNombreEmp.getText());
            ps.setString(2, TxtPuesto.getText());
            ps.setInt(3, Integer.parseInt(TxtNSS.getText()));
            ps.setInt(4, Integer.parseInt(TxtNumTel.getText()));
            ps.setString(5, TxtSangre.getText());
            ps.setString(6, TxtRFCEmp.getText());
            ps.setString(7, TxtCURP.getText());
            int result = ps.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(null, "REGISTRO ACTUALIZADO");
                CleanTexts();
            } else {
                JOptionPane.showMessageDialog(null, "ERROR AL ACTUALIZAR");
            }
            con.close();
        } catch (Exception e) {
            System.err.print(e);
        }
    }//GEN-LAST:event_BtnModificarActionPerformed

    /*
    *VALIDACIONES DE LOS CAMPOS DE TEXTO
     */
    private void TxtNumEmpKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtNumEmpKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 47 || evt.getKeyChar() >= 58 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtNumEmpKeyTyped

    private void TxtNombreEmpKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtNombreEmpKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 64 || evt.getKeyChar() >= 91 && evt.getKeyChar() <= 96 || evt.getKeyChar() >= 123 && evt.getKeyChar() <= 163 || evt.getKeyChar() >= 166 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtNombreEmpKeyTyped

    private void TxtPuestoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtPuestoKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 64 || evt.getKeyChar() >= 91 && evt.getKeyChar() <= 96 || evt.getKeyChar() >= 123 && evt.getKeyChar() <= 163 || evt.getKeyChar() >= 166 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtPuestoKeyTyped

    private void TxtNSSKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtNSSKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 47 || evt.getKeyChar() >= 58 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtNSSKeyTyped

    private void TxtNumTelKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtNumTelKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 42 || evt.getKeyChar() == 44 || evt.getKeyChar() >= 46 && evt.getKeyChar() <= 47 || evt.getKeyChar() >= 58 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtNumTelKeyTyped

    private void TxtSangreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtSangreKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 42 || evt.getKeyChar() == 44 || evt.getKeyChar() >= 46 && evt.getKeyChar() <= 64 || evt.getKeyChar() >= 91 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtSangreKeyTyped

    private void TxtRFCEmpKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtRFCEmpKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 47 || evt.getKeyChar() >= 58 && evt.getKeyChar() <= 64 || evt.getKeyChar() >= 91 && evt.getKeyChar() <= 163 || evt.getKeyChar() >= 166 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtRFCEmpKeyTyped

    private void TxtCURPKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtCURPKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 47 || evt.getKeyChar() >= 58 && evt.getKeyChar() <= 64 || evt.getKeyChar() >= 91 && evt.getKeyChar() <= 163 || evt.getKeyChar() >= 166 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtCURPKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Empleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Empleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Empleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Empleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Empleados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnBuscar;
    private javax.swing.JButton BtnEliminar;
    private javax.swing.JButton BtnModificar;
    private javax.swing.JButton BtnRegistar;
    private javax.swing.JButton BtnSalir;
    private javax.swing.JTable TablaEmp;
    private javax.swing.JTextField TxtCURP;
    private javax.swing.JTextField TxtNSS;
    private javax.swing.JTextField TxtNombreEmp;
    private javax.swing.JTextField TxtNumEmp;
    private javax.swing.JTextField TxtNumTel;
    private javax.swing.JTextField TxtPuesto;
    private javax.swing.JTextField TxtRFCEmp;
    private javax.swing.JTextField TxtSangre;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
