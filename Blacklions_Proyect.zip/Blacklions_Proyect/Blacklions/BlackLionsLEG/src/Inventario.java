
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Inventario extends javax.swing.JFrame {

    public static Connection con;
    public static final String driver = "com.mysql.cj.jdbc.Driver";
    public static final String user = "root";
    public static final String pass = "root";
    public static final String url = "jdbc:mysql://localhost:3306/BlackLionsBD";
    PreparedStatement ps;
    ResultSet rs;
    DefaultTableModel Tabla;

    public void Conexion() {
        /*
        *METODO PARA REALIZAR LA CONEXION A LA BD
         */
        con = null;
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url, user, pass);
            if (con != null) {
                System.out.println("Conexión exitosa!");
            } else {
                System.out.println("No se pudo establecer la conexión.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al registrar: " + e.getMessage());
            e.printStackTrace();
        }

    }

    /*
    *CLASE PARA LIMPIAR LOS TEXTOS UNA VEZ QUE SE USARON
     */
    public void CleanTexts() {
        TxtNombre.setText(null);
        TxtID.setText(null);
        TxtCantidad.setText(null);
        TxtTipo.setText(null);
        TxtColor.setText(null);
    }

    /*
    *CLASE PARA LIMPIAR LA TABLA
     */
    public void CleanTable() {
        while (Tabla.getRowCount() > 0) {
            Tabla.removeRow(0);
        }
        while (TablaInv.getRowCount() > 0) {
            Tabla.removeRow(0);
        }
        Tabla.setColumnCount(0);
    }

    public Inventario() {
        initComponents();
        this.setResizable(false);
        Tabla = new DefaultTableModel();
        TablaInv.setModel(Tabla);
        Tabla.addColumn("ID");          //Campos fijos de la tabla que se mostraran
        Tabla.addColumn("Nombre");
        Tabla.addColumn("Cantidad");
        Tabla.addColumn("Tipo");
        Tabla.addColumn("Color");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TablaInv = new javax.swing.JTable();
        TxtNombre = new javax.swing.JTextField();
        TxtTipo = new javax.swing.JTextField();
        TxtCantidad = new javax.swing.JTextField();
        TxtColor = new javax.swing.JTextField();
        TxtID = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        BtnBuscar = new javax.swing.JButton();
        BtnRegistrar = new javax.swing.JButton();
        BtnEliminar = new javax.swing.JButton();
        BtnModificar = new javax.swing.JButton();
        BtnSalir = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        TablaInv.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID PRODUCTO", "NOMBRE", "CANTIDAD", "COLOR", "TIPO"
            }
        ));
        jScrollPane1.setViewportView(TablaInv);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(0, 380, 770, 250);

        TxtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtNombreKeyTyped(evt);
            }
        });
        getContentPane().add(TxtNombre);
        TxtNombre.setBounds(130, 200, 170, 30);

        TxtTipo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtTipoKeyTyped(evt);
            }
        });
        getContentPane().add(TxtTipo);
        TxtTipo.setBounds(420, 200, 170, 30);

        TxtCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtCantidadKeyTyped(evt);
            }
        });
        getContentPane().add(TxtCantidad);
        TxtCantidad.setBounds(130, 280, 170, 30);

        TxtColor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtColorKeyTyped(evt);
            }
        });
        getContentPane().add(TxtColor);
        TxtColor.setBounds(420, 240, 170, 30);

        TxtID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtIDKeyTyped(evt);
            }
        });
        getContentPane().add(TxtID);
        TxtID.setBounds(130, 240, 170, 30);

        jLabel1.setFont(new java.awt.Font("Lucida Sans", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("INVENTARIO");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 240, 50);

        jLabel2.setFont(new java.awt.Font("Lucida Sans", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ID. PRODUCTO");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 240, 110, 30);

        jLabel3.setFont(new java.awt.Font("Lucida Sans", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("NOMBRE");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(20, 200, 110, 30);

        jLabel4.setFont(new java.awt.Font("Lucida Sans", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("CANTIDAD");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(20, 280, 110, 30);

        jLabel5.setFont(new java.awt.Font("Lucida Sans", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("COLOR");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(340, 240, 80, 30);

        jLabel6.setFont(new java.awt.Font("Lucida Sans", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("TIPO");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(340, 200, 80, 30);

        BtnBuscar.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Buscar_72.png"))); // NOI18N
        BtnBuscar.setText("BUSCAR");
        BtnBuscar.setToolTipText("Coloca el nombre del producto que\ndeseas buscar en campo de texto de \"Nombre\"\ny presiona buscar\n");
        BtnBuscar.setContentAreaFilled(false);
        BtnBuscar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnBuscar.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Buscar_64.png"))); // NOI18N
        BtnBuscar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnBuscar);
        BtnBuscar.setBounds(100, 60, 130, 100);

        BtnRegistrar.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnRegistrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/gardar_64.png"))); // NOI18N
        BtnRegistrar.setText("REGISTAR");
        BtnRegistrar.setToolTipText("Para guardar solo presiona \"GUARDAR\" una vez todos los\ncampos esten llenos\n");
        BtnRegistrar.setContentAreaFilled(false);
        BtnRegistrar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnRegistrar.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/guardar_48.png"))); // NOI18N
        BtnRegistrar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnRegistrarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnRegistrar);
        BtnRegistrar.setBounds(240, 60, 130, 100);

        BtnEliminar.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Eliminar_64.png"))); // NOI18N
        BtnEliminar.setText("ELIMINAR");
        BtnEliminar.setToolTipText("Para eliminar debes colocar el ID del producto \nen su campo de texto y luego presionar Eliminar\n");
        BtnEliminar.setContentAreaFilled(false);
        BtnEliminar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnEliminar.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Eliminar_48.png"))); // NOI18N
        BtnEliminar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEliminarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnEliminar);
        BtnEliminar.setBounds(380, 60, 130, 100);

        BtnModificar.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Editar_64.png"))); // NOI18N
        BtnModificar.setText("MODIFICAR");
        BtnModificar.setToolTipText("");
        BtnModificar.setContentAreaFilled(false);
        BtnModificar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnModificar.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Editar_48.png"))); // NOI18N
        BtnModificar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnModificarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnModificar);
        BtnModificar.setBounds(520, 60, 130, 100);

        BtnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cerrar_64.png"))); // NOI18N
        BtnSalir.setContentAreaFilled(false);
        BtnSalir.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cerrar_48.png"))); // NOI18N
        BtnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnSalirMouseClicked(evt);
            }
        });
        getContentPane().add(BtnSalir);
        BtnSalir.setBounds(700, 0, 70, 60);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Fondo_Menus.jpg"))); // NOI18N
        getContentPane().add(jLabel7);
        jLabel7.setBounds(0, 0, 940, 610);

        setSize(new java.awt.Dimension(781, 548));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void TxtIDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtIDKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 47 || evt.getKeyChar() >= 58 && evt.getKeyChar() <= 255) { //VALIDACIONES PARA SOLO PONER NUMEROS
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtIDKeyTyped

    private void TxtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtNombreKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 64 || evt.getKeyChar() >= 91 && evt.getKeyChar() <= 96 || evt.getKeyChar() >= 123 && evt.getKeyChar() <= 163 || evt.getKeyChar() >= 166 && evt.getKeyChar() <= 255) { //VALIDACIONES PARA SOLO PONER LETRAS
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtNombreKeyTyped

    private void TxtColorKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtColorKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 64 || evt.getKeyChar() >= 91 && evt.getKeyChar() <= 96 || evt.getKeyChar() >= 123 && evt.getKeyChar() <= 163 || evt.getKeyChar() >= 166 && evt.getKeyChar() <= 255) { //VALIDACIONES PARA SOLO PONER LETRAS
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtColorKeyTyped

    private void TxtCantidadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtCantidadKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 45 || evt.getKeyChar() == 47 || evt.getKeyChar() >= 58 && evt.getKeyChar() <= 255) { //VALIDACIONES PARA SOLO PONER NUMEROS
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtCantidadKeyTyped

    private void BtnSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnSalirMouseClicked
        new MenuPrincipal().setVisible(true); //METODO PARA REGRESAR A LA VENTANA DEL MENU PRINCIPAL
        this.setVisible(false); //METODO PARA ESCONDER ESTA VENTANA
    }//GEN-LAST:event_BtnSalirMouseClicked

    private void BtnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEliminarActionPerformed
        /*
        *METODO PARA EL BOTON DE ELIMINAR UN REGISTRO DE LA BD EN LA TABLA DE INVENTARIO
         */

        Conexion();
        try {
            ps = con.prepareStatement("DELETE FROM Inventario WHERE ID=?");
            ps.setInt(1, Integer.parseInt(TxtID.getText()));
            int res = ps.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "SE HA ELIMINADO EL REGISTRO EXITOSAMENTE");
                CleanTexts();
            } else {
                JOptionPane.showMessageDialog(null, "NO SE HA PODIDO ELIMINAR EL REGISTRO");
            }
        } catch (Exception e) {
            System.err.print(e);
        }
    }//GEN-LAST:event_BtnEliminarActionPerformed

    private void BtnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnRegistrarActionPerformed
        /*
        *METODO PARA EL BOTON DE REGISTAR UN REGISTRO UN LA BD
         */
        Conexion();
        try {
            ps = con.prepareStatement("INSERT INTO Inventario(ID,Nombre,Cantidad,Tipo,Color) VALUES(?,?,?,?,?)");
            ps.setInt(1, Integer.parseInt(TxtID.getText()));
            ps.setString(2, TxtNombre.getText());
            ps.setInt(3, Integer.parseInt(TxtCantidad.getText()));
            ps.setString(4, TxtTipo.getText());
            ps.setString(5, TxtColor.getText());
            int result = ps.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(null, "REGISTRO GUARDADO");
                CleanTexts();
            } else {
                JOptionPane.showMessageDialog(null, "ERROR AL REGISTRAR");
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace(); // Imprime el stack trace para más detalles
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }//GEN-LAST:event_BtnRegistrarActionPerformed

    private void BtnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBuscarActionPerformed
        /*
        *METODO PARA EL BOTON DE BUSCAR UN REGISTRO EN LA BD
         */
        int band = 0; //BANDERA PARA VALIDAR SI SE ENCONTRO EL REGISTRO BUSCADO
        Conexion();
        /*
        * IF PARA REALIZAR UNA CONSULTA GENERAL CUANDO NO HAYA NADA EN EL CAMPO DE TEXTO
         */
        if (TxtNombre.getText().equals("")) {
            try {
                ps = con.prepareStatement("SELECT * FROM Inventario");
                Tabla.setRowCount(0);
                rs = ps.executeQuery();
                while (rs.next()) {
                    band = 1;
                    Tabla.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
                    CleanTexts();
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        } else {
            try {
                ps = con.prepareStatement("SELECT * FROM Inventario WHERE Nombre=?");
                ps.setString(1, TxtNombre.getText());
                Tabla.setRowCount(0);
                rs = ps.executeQuery();
                while (rs.next()) {
                    band = 1;
                    Tabla.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
                    CleanTexts();
                }
                if (band == 0) {
                    JOptionPane.showMessageDialog(null, "REGISTRO NO ENCONTRADO");
                    CleanTexts();
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }//GEN-LAST:event_BtnBuscarActionPerformed

    private void BtnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnModificarActionPerformed
        /*
        *MÉTODO PARA EL BOTON DE MODIFICAR ALGUN REGISTRO DE LA BD 
         */
        Conexion();
        try {
            ps = con.prepareStatement("UPDATE Inventario SET Nombre=?,Cantidad=?,Tipo=?,Color=? WHERE ID=?");
            ps.setInt(5, Integer.parseInt(TxtID.getText()));
            ps.setString(1, TxtNombre.getText());
            ps.setInt(2, Integer.parseInt(TxtCantidad.getText()));
            ps.setString(3, TxtTipo.getText());
            ps.setString(4, TxtColor.getText());
            int result = ps.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(null, "REGISTRO ACTUALIZADO");
                CleanTexts();
            } else {
                JOptionPane.showMessageDialog(null, "ERROR AL ACTUALIZAR");
            }
            con.close();
        } catch (Exception e) {
            System.err.print(e);
        }
    }//GEN-LAST:event_BtnModificarActionPerformed

    private void TxtTipoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtTipoKeyTyped
        //METODO DE VALIDACION PARA ADMITIR SOLO LETRAS
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 64 || evt.getKeyChar() >= 91 && evt.getKeyChar() <= 96 || evt.getKeyChar() >= 123 && evt.getKeyChar() <= 163 || evt.getKeyChar() >= 166 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtTipoKeyTyped

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                

}
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inventario.class  

.getName()).log(java.util.logging.Level.SEVERE, null, ex);

} catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inventario.class  

.getName()).log(java.util.logging.Level.SEVERE, null, ex);

} catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inventario.class  

.getName()).log(java.util.logging.Level.SEVERE, null, ex);

} catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inventario.class  

.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inventario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnBuscar;
    private javax.swing.JButton BtnEliminar;
    private javax.swing.JButton BtnModificar;
    private javax.swing.JButton BtnRegistrar;
    private javax.swing.JButton BtnSalir;
    private javax.swing.JTable TablaInv;
    private javax.swing.JTextField TxtCantidad;
    private javax.swing.JTextField TxtColor;
    private javax.swing.JTextField TxtID;
    private javax.swing.JTextField TxtNombre;
    private javax.swing.JTextField TxtTipo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
