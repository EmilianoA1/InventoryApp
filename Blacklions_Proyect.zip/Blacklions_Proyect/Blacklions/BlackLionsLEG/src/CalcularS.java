import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author emili
 */
public class CalcularS extends javax.swing.JFrame {

    
    private void CleanTexts(){
        /*
        *METODO PARA LIMPAR LOS CAMPOS DE TEXTO 
        */
        TxtDescuento.setText(null);
        TxtDias.setText(null);
        TxtMontoB.setText(null);
        TxtPagoD.setText(null);
        TxtSueldoB.setText(null);
        TxtSueldoBruto.setText(null);
        TxtSueldoNeto.setText(null);
    }
    
    
    
    public CalcularS() {
        initComponents();
        this.setResizable(false);  
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        TxtDias = new javax.swing.JTextField();
        TxtPagoD = new javax.swing.JTextField();
        TxtSueldoB = new javax.swing.JTextField();
        TxtMontoB = new javax.swing.JTextField();
        TxtSueldoBruto = new javax.swing.JTextField();
        TxtDescuento = new javax.swing.JTextField();
        TxtSueldoNeto = new javax.swing.JTextField();
        BtnCalcular = new javax.swing.JButton();
        BtnNuevo = new javax.swing.JButton();
        BtnGuardar = new javax.swing.JButton();
        BtnSalir = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("DIAS TRABAJADOS ");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 60, 140, 40);

        jLabel2.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("PAGO POR DIA");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(400, 60, 130, 40);

        jLabel3.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel3.setText("SUELDO BASICO");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(0, 190, 170, 40);

        jLabel4.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel4.setText("MONTO BONIFICACION");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(0, 240, 170, 40);

        jLabel5.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel5.setText("SUELDO BRUTO");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(0, 290, 170, 40);

        jLabel6.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel6.setText("MONTO DESCUENTO");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(0, 340, 170, 40);

        jLabel7.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        jLabel7.setText("SUELDO NETO");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(0, 390, 170, 40);

        jLabel8.setFont(new java.awt.Font("Lucida Sans", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("CALCULAR SALARIO");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(0, 0, 490, 50);

        TxtDias.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtDiasKeyTyped(evt);
            }
        });
        getContentPane().add(TxtDias);
        TxtDias.setBounds(140, 60, 240, 40);

        TxtPagoD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TxtPagoDKeyTyped(evt);
            }
        });
        getContentPane().add(TxtPagoD);
        TxtPagoD.setBounds(530, 60, 240, 40);
        getContentPane().add(TxtSueldoB);
        TxtSueldoB.setBounds(170, 190, 210, 40);
        getContentPane().add(TxtMontoB);
        TxtMontoB.setBounds(170, 240, 210, 40);
        getContentPane().add(TxtSueldoBruto);
        TxtSueldoBruto.setBounds(170, 290, 210, 40);
        getContentPane().add(TxtDescuento);
        TxtDescuento.setBounds(170, 340, 210, 40);
        getContentPane().add(TxtSueldoNeto);
        TxtSueldoNeto.setBounds(170, 390, 210, 40);

        BtnCalcular.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnCalcular.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Calcular_72.png"))); // NOI18N
        BtnCalcular.setText("CALCULAR");
        BtnCalcular.setContentAreaFilled(false);
        BtnCalcular.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnCalcular.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Calcular_64.png"))); // NOI18N
        BtnCalcular.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCalcularActionPerformed(evt);
            }
        });
        getContentPane().add(BtnCalcular);
        BtnCalcular.setBounds(400, 230, 140, 100);

        BtnNuevo.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Nuevo_72.png"))); // NOI18N
        BtnNuevo.setText("NUEVO");
        BtnNuevo.setContentAreaFilled(false);
        BtnNuevo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnNuevo.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Nuevo_64.png"))); // NOI18N
        BtnNuevo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnNuevoActionPerformed(evt);
            }
        });
        getContentPane().add(BtnNuevo);
        BtnNuevo.setBounds(540, 230, 140, 100);

        BtnGuardar.setFont(new java.awt.Font("Lucida Sans", 1, 13)); // NOI18N
        BtnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/gardar_64.png"))); // NOI18N
        BtnGuardar.setText("GUARDAR");
        BtnGuardar.setContentAreaFilled(false);
        BtnGuardar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BtnGuardar.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/guardar_48.png"))); // NOI18N
        BtnGuardar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        BtnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnGuardar);
        BtnGuardar.setBounds(680, 230, 140, 100);

        BtnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cerrar_64.png"))); // NOI18N
        BtnSalir.setContentAreaFilled(false);
        BtnSalir.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cerrar_48.png"))); // NOI18N
        BtnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnSalirMouseClicked(evt);
            }
        });
        BtnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(BtnSalir);
        BtnSalir.setBounds(800, 0, 50, 50);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 170, 380, 270);

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Fondo_Menus.jpg"))); // NOI18N
        getContentPane().add(jLabel9);
        jLabel9.setBounds(1, -4, 970, 580);

        setSize(new java.awt.Dimension(869, 484));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BtnCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCalcularActionPerformed
        // TODO add your handling code here:
        /*
        *METODO PARA CALCULAR EL SALARIO DEL EMPLEADO DEPENDEINDO DE LOS DIAS QUE TRABAJO Y SU SALARIO POR DIA
        */
        double diasTrabajados, tarifaDiaria; 
        double sueldobasico,bonificacion,sueldobruto,descuento,sueldoneto;
        
        diasTrabajados = Double.parseDouble(TxtDias.getText());
        tarifaDiaria = Double.parseDouble(TxtPagoD.getText());
        
        sueldobasico = diasTrabajados*tarifaDiaria;
        bonificacion = sueldobasico*0.2;
        sueldobruto = sueldobasico+bonificacion;
        descuento = sueldobruto*0.1;
        sueldoneto = sueldobruto-descuento; 
        
        TxtSueldoB.setText(String.valueOf(sueldobasico));
        TxtMontoB.setText(String.valueOf(bonificacion));
        TxtSueldoBruto.setText(String.valueOf(sueldobruto));
        TxtDescuento.setText(String.valueOf(descuento));
        TxtSueldoNeto.setText(String.valueOf(sueldoneto));
    }//GEN-LAST:event_BtnCalcularActionPerformed

    private void BtnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnNuevoActionPerformed
        //BOTON PARA LIMPIAR LOS CAMPOS DE TEXTO
        CleanTexts();
    }//GEN-LAST:event_BtnNuevoActionPerformed

    private void BtnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnSalirActionPerformed
        
    }//GEN-LAST:event_BtnSalirActionPerformed

    private void BtnSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnSalirMouseClicked
        //BOTON PARA SALIR DE LA VENTANA
        this.setVisible(false);
    }//GEN-LAST:event_BtnSalirMouseClicked

    private void BtnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnGuardarActionPerformed
        //METODO PARA ENVIAR LOS DATOS DEL SUELDO Y EL DESCUENTO A LA VENTANA DE LA NOMINA
        Nomina.TxtSueldo.setText(TxtSueldoNeto.getText());
        Nomina.TxtDesc.setText(TxtDescuento.getText());
    }//GEN-LAST:event_BtnGuardarActionPerformed

    /*
    *VALIDACIONES PARA LOS CAMPOS DE TEXTO
    */
    private void TxtDiasKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtDiasKeyTyped
        if (evt.getKeyChar() >= 33 && evt.getKeyChar() <= 47 || evt.getKeyChar() >= 58 && evt.getKeyChar() <= 255) {
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtDiasKeyTyped

    private void TxtPagoDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtPagoDKeyTyped
        if(evt.getKeyChar()>=33 && evt.getKeyChar()<=45 || evt.getKeyChar()==47 || evt.getKeyChar() >= 58 && evt.getKeyChar() <= 255){
            evt.consume();
            JOptionPane.showMessageDialog(null, "CARACTER INVALIDO");
        }
    }//GEN-LAST:event_TxtPagoDKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CalcularS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CalcularS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CalcularS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CalcularS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CalcularS().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnCalcular;
    private javax.swing.JButton BtnGuardar;
    private javax.swing.JButton BtnNuevo;
    private javax.swing.JButton BtnSalir;
    public static javax.swing.JTextField TxtDescuento;
    private javax.swing.JTextField TxtDias;
    private javax.swing.JTextField TxtMontoB;
    private javax.swing.JTextField TxtPagoD;
    private javax.swing.JTextField TxtSueldoB;
    private javax.swing.JTextField TxtSueldoBruto;
    public static javax.swing.JTextField TxtSueldoNeto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
